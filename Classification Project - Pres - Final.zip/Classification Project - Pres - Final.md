```python
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split, StratifiedKFold,KFold
from datetime import datetime
from sklearn.metrics import precision_score, recall_score, confusion_matrix, accuracy_score, roc_auc_score, f1_score, roc_curve, auc,precision_recall_curve
from sklearn import metrics
from sklearn import preprocessing
import warnings
warnings.filterwarnings("ignore")
import itertools
from scipy import interp
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
from matplotlib import rcParams
```


```python
data = pd.read_csv("E:\Projects folder\census\\census1.csv")
print("Number of Observations in adult dataset:", data.shape)
data.head()
```

    Number of Observations in adult dataset: (199523, 42)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>class</th>
      <th>industry_code</th>
      <th>occupation_code</th>
      <th>education</th>
      <th>wage_hour</th>
      <th>enrolled edu inst last wk</th>
      <th>marital status</th>
      <th>major_industry_code</th>
      <th>major_occupation_code</th>
      <th>...</th>
      <th>country_birth_mother</th>
      <th>country_birth_self</th>
      <th>citizenship</th>
      <th>business_type</th>
      <th>taxable_inc_amount</th>
      <th>veterans_questionnaire</th>
      <th>veterans_benefits</th>
      <th>weeks_year</th>
      <th>instance_weight</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>73</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>High school graduate</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Widowed</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>0</td>
      <td>95</td>
      <td>-50000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>58</td>
      <td>Self-employed-not incorporated</td>
      <td>4</td>
      <td>34</td>
      <td>Some college but no degree</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Divorced</td>
      <td>Construction</td>
      <td>Precision production craft &amp; repair</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>52</td>
      <td>94</td>
      <td>-50000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>10th grade</td>
      <td>0</td>
      <td>High school</td>
      <td>Never married</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>Vietnam</td>
      <td>Vietnam</td>
      <td>Vietnam</td>
      <td>Foreign born- Not a citizen of U S</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>0</td>
      <td>95</td>
      <td>-50000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>Children</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Never married</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>94</td>
      <td>-50000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>Children</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Never married</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>94</td>
      <td>-50000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 42 columns</p>
</div>




```python
#data.columns = ['age', 'class',
 #              'industry_code','occupation_code','education', 
 #               'wage_hour', 'enrolled_edu_inst_last_wk', 'marital_status' ,'industry_code1', 'occupation_code1', 
 #               'mace' ,'hispanic', 'sex' ,'member_labor_union', 'reason_unemployment' ,
 #               'employment_type' ,'capital_gains' ,'capital_losses' ,
 #               'divdend_stocks', 'tax_status' ,'region_previous_residence','state_previous_residence' ,
 #               'household_family_stat' ,'summary_household' ,'migration_code_change_msa', 'migration_code_change_reg',
 #               'migration code-move within reg','stay_same_house_1','migration_prev_res_sunbelt', 
 #               'num_persons_worked_employer', 'family_below_18','country_birth_father','country_birth_mother' ,
 #               'country_birth_self' ,'citizenship','business_type','taxable_inc_amount', 'veterans_questionnaire' ,
 #               'veterans_benefits' ,'weeks_year' ,'instance_weight', 'income'  ]
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 199523 entries, 0 to 199522
    Data columns (total 42 columns):
    age                               199523 non-null int64
    class                             199523 non-null object
    industry_code                     199523 non-null int64
    occupation_code                   199523 non-null int64
    education                         199523 non-null object
    wage_hour                         199523 non-null int64
    enrolled edu inst last wk         199523 non-null object
    marital status                    199523 non-null object
    major_industry_code               199523 non-null object
    major_occupation_code             199523 non-null object
    mace                              199523 non-null object
    hispanic                          199523 non-null object
    sex                               199523 non-null object
    member_labor_union                199523 non-null object
    reason_unemployment               199523 non-null object
    employment_type                   199523 non-null object
    capital_gains                     199523 non-null int64
    capital_losses                    199523 non-null int64
    divdend_stocks                    199523 non-null int64
    tax_status                        199523 non-null object
    region_previous_residence         199523 non-null object
    state_previous_residence          199523 non-null object
    household_family_stat             199523 non-null object
    summary_household                 199523 non-null object
    migration_code_change_msa         199523 non-null float64
    migration_code_change_reg         199523 non-null object
    migration code-move within reg    199523 non-null object
    stay_same_house_1                 199523 non-null object
    migration_prev_res_sunbelt        199523 non-null object
    num_persons_worked_employer       199523 non-null object
    family_below_18                   199523 non-null int64
    country_birth_father              199523 non-null object
    country_birth_mother              199523 non-null object
    country_birth_self                199523 non-null object
    citizenship                       199523 non-null object
    business_type                     199523 non-null object
    taxable_inc_amount                199523 non-null int64
    veterans_questionnaire            199523 non-null object
    veterans_benefits                 199523 non-null int64
    weeks_year                        199523 non-null int64
    instance_weight                   199523 non-null int64
    income                            199523 non-null object
    dtypes: float64(1), int64(12), object(29)
    memory usage: 63.9+ MB
    


```python
pd.isnull(data).any()

#checking for nulls
```




    age                               False
    class                             False
    industry_code                     False
    occupation_code                   False
    education                         False
    wage_hour                         False
    enrolled edu inst last wk         False
    marital status                    False
    major_industry_code               False
    major_occupation_code             False
    mace                              False
    hispanic                          False
    sex                               False
    member_labor_union                False
    reason_unemployment               False
    employment_type                   False
    capital_gains                     False
    capital_losses                    False
    divdend_stocks                    False
    tax_status                        False
    region_previous_residence         False
    state_previous_residence          False
    household_family_stat             False
    summary_household                 False
    migration_code_change_msa         False
    migration_code_change_reg         False
    migration code-move within reg    False
    stay_same_house_1                 False
    migration_prev_res_sunbelt        False
    num_persons_worked_employer       False
    family_below_18                   False
    country_birth_father              False
    country_birth_mother              False
    country_birth_self                False
    citizenship                       False
    business_type                     False
    taxable_inc_amount                False
    veterans_questionnaire            False
    veterans_benefits                 False
    weeks_year                        False
    instance_weight                   False
    income                            False
    dtype: bool




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>industry_code</th>
      <th>occupation_code</th>
      <th>wage_hour</th>
      <th>capital_gains</th>
      <th>capital_losses</th>
      <th>divdend_stocks</th>
      <th>migration_code_change_msa</th>
      <th>family_below_18</th>
      <th>taxable_inc_amount</th>
      <th>veterans_benefits</th>
      <th>weeks_year</th>
      <th>instance_weight</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.00000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
      <td>199523.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>34.494199</td>
      <td>15.352320</td>
      <td>11.306556</td>
      <td>55.426908</td>
      <td>434.71899</td>
      <td>37.313788</td>
      <td>197.529533</td>
      <td>1740.380269</td>
      <td>1.956180</td>
      <td>0.175438</td>
      <td>1.514833</td>
      <td>23.174897</td>
      <td>94.499672</td>
    </tr>
    <tr>
      <th>std</th>
      <td>22.310895</td>
      <td>18.067129</td>
      <td>14.454204</td>
      <td>274.896454</td>
      <td>4697.53128</td>
      <td>271.896428</td>
      <td>1984.163658</td>
      <td>993.768156</td>
      <td>2.365126</td>
      <td>0.553694</td>
      <td>0.851473</td>
      <td>24.411488</td>
      <td>0.500001</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>37.870000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>94.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>15.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1061.615000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>94.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>33.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1618.310000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>8.000000</td>
      <td>94.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>50.000000</td>
      <td>33.000000</td>
      <td>26.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2188.610000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>52.000000</td>
      <td>95.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>90.000000</td>
      <td>51.000000</td>
      <td>46.000000</td>
      <td>9999.000000</td>
      <td>99999.00000</td>
      <td>4608.000000</td>
      <td>99999.000000</td>
      <td>18656.300000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>52.000000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>class</th>
      <th>industry_code</th>
      <th>occupation_code</th>
      <th>education</th>
      <th>wage_hour</th>
      <th>enrolled edu inst last wk</th>
      <th>marital status</th>
      <th>major_industry_code</th>
      <th>major_occupation_code</th>
      <th>...</th>
      <th>country_birth_mother</th>
      <th>country_birth_self</th>
      <th>citizenship</th>
      <th>business_type</th>
      <th>taxable_inc_amount</th>
      <th>veterans_questionnaire</th>
      <th>veterans_benefits</th>
      <th>weeks_year</th>
      <th>instance_weight</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>73</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>High school graduate</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Widowed</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>0</td>
      <td>95</td>
      <td>-50000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>58</td>
      <td>Self-employed-not incorporated</td>
      <td>4</td>
      <td>34</td>
      <td>Some college but no degree</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Divorced</td>
      <td>Construction</td>
      <td>Precision production craft &amp; repair</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>52</td>
      <td>94</td>
      <td>-50000</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 42 columns</p>
</div>




```python
data['income'].value_counts(dropna=False, normalize=True).head()
#checking for balance of the target. It shows the target is highly imbalance.
```




    -50000      0.937942
     50000+.    0.062058
    Name: income, dtype: float64




```python
data['income']=data['income'].map({'-50000': 0, ' 50000+.': 1})
data.head(4)
#mapping the target the variable
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>class</th>
      <th>industry_code</th>
      <th>occupation_code</th>
      <th>education</th>
      <th>wage_hour</th>
      <th>enrolled edu inst last wk</th>
      <th>marital status</th>
      <th>major_industry_code</th>
      <th>major_occupation_code</th>
      <th>...</th>
      <th>country_birth_mother</th>
      <th>country_birth_self</th>
      <th>citizenship</th>
      <th>business_type</th>
      <th>taxable_inc_amount</th>
      <th>veterans_questionnaire</th>
      <th>veterans_benefits</th>
      <th>weeks_year</th>
      <th>instance_weight</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>73</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>High school graduate</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Widowed</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>0</td>
      <td>95</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>58</td>
      <td>Self-employed-not incorporated</td>
      <td>4</td>
      <td>34</td>
      <td>Some college but no degree</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Divorced</td>
      <td>Construction</td>
      <td>Precision production craft &amp; repair</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>52</td>
      <td>94</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>10th grade</td>
      <td>0</td>
      <td>High school</td>
      <td>Never married</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>Vietnam</td>
      <td>Vietnam</td>
      <td>Vietnam</td>
      <td>Foreign born- Not a citizen of U S</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>2</td>
      <td>0</td>
      <td>95</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>Children</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>Never married</td>
      <td>Not in universe or children</td>
      <td>Not in universe</td>
      <td>...</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>United-States</td>
      <td>Native- Born in the United States</td>
      <td>0</td>
      <td>Not in universe</td>
      <td>0</td>
      <td>0</td>
      <td>94</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 42 columns</p>
</div>




```python
#Separate categorical and numerical columns
cat_column = data.dtypes[data.dtypes == 'object']

```


```python
for col in list(cat_column.index):
    print(f"--------------------{col.title()}-------------------------")
    total= data[col].value_counts()
    percent = total / data.shape[0]
    df = pd.concat([total,percent],keys = ['total','percent'],axis = 1)
    print(df)
    print('\n')
    
    
#State_Previous_Residence, Migration_Code_Change_Reg, Migration Code-Move Within Reg
#Stay_Same_House_1, Num_Persons_Worked_Employer, Num_Persons_Worked_Employer, Country_Birth_Mother, Country_Birth_Self
# Citizenship

#has unknown values represented by ?

#Education

#9th, 10th, 11th, 12th comes under HighSchool Grad but it has mentioned separately
#Create Elementary object for 1st-4th, 5th-6th, 7th-8th

#Marital Status

#Married-civilian spouse present,Married-spouse absent, Married-A F spouse present comes under Married separated.
#Divorced, separated, windowed comes under category separated.

#class

#Self-emp-not-incor, Self-emp-incor comes under category self employed
#Local-gov,State-gov,Federal-gov comes under category goverment emloyees


```

    --------------------Class-------------------------
                                      total   percent
     Not in universe                 100245  0.502423
     Private                          72028  0.361001
     Self-employed-not incorporated    8445  0.042326
     Local government                  7784  0.039013
     State government                  4227  0.021186
     Self-employed-incorporated        3265  0.016364
     Federal government                2925  0.014660
     Never worked                       439  0.002200
     Without pay                        165  0.000827
    
    
    --------------------Education-------------------------
                                             total   percent
     High school graduate                    48407  0.242614
     Children                                47422  0.237677
     Some college but no degree              27820  0.139433
     Bachelors degree(BA AB BS)              19865  0.099562
     7th and 8th grade                        8007  0.040131
     10th grade                               7557  0.037875
     11th grade                               6876  0.034462
     Masters degree(MA MS MEng MEd MSW MBA)   6541  0.032783
     9th grade                                6230  0.031224
     Associates degree-occup /vocational      5358  0.026854
     Associates degree-academic program       4363  0.021867
     5th or 6th grade                         3277  0.016424
     12th grade no diploma                    2126  0.010655
     1st 2nd 3rd or 4th grade                 1799  0.009017
     Prof school degree (MD DDS DVM LLB JD)   1793  0.008986
     Doctorate degree(PhD EdD)                1263  0.006330
     Less than 1st grade                       819  0.004105
    
    
    --------------------Enrolled Edu Inst Last Wk-------------------------
                             total   percent
     Not in universe        186943  0.936950
     High school              6892  0.034542
     College or university    5688  0.028508
    
    
    --------------------Marital Status-------------------------
                                      total   percent
     Never married                    86485  0.433459
     Married-civilian spouse present  84222  0.422117
     Divorced                         12710  0.063702
     Widowed                          10463  0.052440
     Separated                         3460  0.017341
     Married-spouse absent             1518  0.007608
     Married-A F spouse present         665  0.003333
    
    
    --------------------Major_Industry_Code-------------------------
                                           total   percent
     Not in universe or children          100684  0.504624
     Retail trade                          17070  0.085554
     Manufacturing-durable goods            9015  0.045183
     Education                              8283  0.041514
     Manufacturing-nondurable goods         6897  0.034567
     Finance insurance and real estate      6145  0.030798
     Construction                           5984  0.029992
     Business and repair services           5651  0.028323
     Medical except hospital                4683  0.023471
     Public administration                  4610  0.023105
     Other professional services            4482  0.022464
     Transportation                         4209  0.021095
     Hospital services                      3964  0.019867
     Wholesale trade                        3596  0.018023
     Agriculture                            3023  0.015151
     Personal services except private HH    2937  0.014720
     Social services                        2549  0.012775
     Entertainment                          1651  0.008275
     Communications                         1181  0.005919
     Utilities and sanitary services        1178  0.005904
     Private household services              945  0.004736
     Mining                                  563  0.002822
     Forestry and fisheries                  187  0.000937
     Armed Forces                             36  0.000180
    
    
    --------------------Major_Occupation_Code-------------------------
                                             total   percent
     Not in universe                        100684  0.504624
     Adm support including clerical          14837  0.074362
     Professional specialty                  13940  0.069867
     Executive admin and managerial          12495  0.062624
     Other service                           12099  0.060640
     Sales                                   11783  0.059056
     Precision production craft & repair     10518  0.052716
     Machine operators assmblrs & inspctrs    6379  0.031971
     Handlers equip cleaners etc              4127  0.020684
     Transportation and material moving       4020  0.020148
     Farming forestry and fishing             3146  0.015768
     Technicians and related support          3018  0.015126
     Protective services                      1661  0.008325
     Private household services                780  0.003909
     Armed Forces                               36  0.000180
    
    
    --------------------Mace-------------------------
                                   total   percent
     White                        167365  0.838826
     Black                         20415  0.102319
     Asian or Pacific Islander      5835  0.029245
     Other                          3657  0.018329
     Amer Indian Aleut or Eskimo    2251  0.011282
    
    
    --------------------Hispanic-------------------------
                                 total   percent
     All other                  171907  0.861590
     Mexican-American             8079  0.040492
     Mexican (Mexicano)           7234  0.036256
     Central or South American    3895  0.019522
     Puerto Rican                 3313  0.016605
     Other Spanish                2485  0.012455
     Cuban                        1126  0.005643
     NA                            874  0.004380
     Do not know                   306  0.001534
     Chicano                       304  0.001524
    
    
    --------------------Sex-------------------------
              total   percent
     Female  103984  0.521163
     Male     95539  0.478837
    
    
    --------------------Member_Labor_Union-------------------------
                       total   percent
     Not in universe  180459  0.904452
     No                16034  0.080362
     Yes                3030  0.015186
    
    
    --------------------Reason_Unemployment-------------------------
                             total   percent
     Not in universe        193453  0.969577
     Other job loser          2038  0.010214
     Re-entrant               2019  0.010119
     Job loser - on layoff     976  0.004892
     Job leaver                598  0.002997
     New entrant               439  0.002200
    
    
    --------------------Employment_Type-------------------------
                                          total   percent
     Children or Armed Forces            123769  0.620324
     Full-time schedules                  40736  0.204167
     Not in labor force                   26808  0.134360
     PT for non-econ reasons usually FT    3322  0.016650
     Unemployed full-time                  2311  0.011583
     PT for econ reasons usually PT        1209  0.006059
     Unemployed part- time                  843  0.004225
     PT for econ reasons usually FT         525  0.002631
    
    
    --------------------Tax_Status-------------------------
                                   total   percent
     Nonfiler                      75094  0.376368
     Joint both under 65           67383  0.337720
     Single                        37421  0.187552
     Joint both 65+                 8332  0.041760
     Head of household              7426  0.037219
     Joint one under 65 & one 65+   3867  0.019381
    
    
    --------------------Region_Previous_Residence-------------------------
                       total   percent
     Not in universe  183750  0.920946
     South              4889  0.024503
     West               4074  0.020419
     Midwest            3575  0.017918
     Northeast          2705  0.013557
     Abroad              530  0.002656
    
    
    --------------------State_Previous_Residence-------------------------
                            total   percent
     Not in universe       183750  0.920946
     California              1714  0.008590
     Utah                    1063  0.005328
     Florida                  849  0.004255
     North Carolina           812  0.004070
     ?                        708  0.003548
     Abroad                   671  0.003363
     Oklahoma                 626  0.003137
     Minnesota                576  0.002887
     Indiana                  533  0.002671
     North Dakota             499  0.002501
     New Mexico               463  0.002321
     Michigan                 441  0.002210
     Alaska                   290  0.001453
     Kentucky                 244  0.001223
     Arizona                  243  0.001218
     New Hampshire            242  0.001213
     Wyoming                  241  0.001208
     Colorado                 239  0.001198
     Oregon                   236  0.001183
     West Virginia            231  0.001158
     Georgia                  227  0.001138
     Montana                  226  0.001133
     Alabama                  216  0.001083
     Ohio                     211  0.001058
     Texas                    209  0.001047
     Arkansas                 205  0.001027
     Mississippi              204  0.001022
     Tennessee                202  0.001012
     Pennsylvania             199  0.000997
     New York                 195  0.000977
     Louisiana                192  0.000962
     Vermont                  191  0.000957
     Iowa                     189  0.000947
     Illinois                 180  0.000902
     Nebraska                 178  0.000892
     Missouri                 175  0.000877
     Nevada                   174  0.000872
     Maine                    167  0.000837
     Massachusetts            151  0.000757
     Kansas                   149  0.000747
     South Dakota             138  0.000692
     Maryland                 136  0.000682
     Virginia                 126  0.000632
     Connecticut              117  0.000586
     District of Columbia     116  0.000581
     Wisconsin                105  0.000526
     South Carolina            95  0.000476
     New Jersey                75  0.000376
     Delaware                  73  0.000366
     Idaho                     31  0.000155
    
    
    --------------------Household_Family_Stat-------------------------
                                                      total   percent
     Householder                                      53248  0.266877
     Child <18 never marr not in subfamily            50326  0.252232
     Spouse of householder                            41695  0.208973
     Nonfamily householder                            22213  0.111331
     Child 18+ never marr Not in a subfamily          12030  0.060294
     Secondary individual                              6122  0.030683
     Other Rel 18+ ever marr not in subfamily          1956  0.009803
     Grandchild <18 never marr child of subfamily RP   1868  0.009362
     Other Rel 18+ never marr not in subfamily         1728  0.008661
     Grandchild <18 never marr not in subfamily        1066  0.005343
     Child 18+ ever marr Not in a subfamily            1013  0.005077
     Child under 18 of RP of unrel subfamily            732  0.003669
     RP of unrelated subfamily                          685  0.003433
     Child 18+ ever marr RP of subfamily                671  0.003363
     Other Rel <18 never marr child of subfamily RP     656  0.003288
     Other Rel 18+ ever marr RP of subfamily            656  0.003288
     Other Rel 18+ spouse of subfamily RP               638  0.003198
     Child 18+ never marr RP of subfamily               589  0.002952
     Other Rel <18 never marr not in subfamily          584  0.002927
     Grandchild 18+ never marr not in subfamily         375  0.001879
     In group quarters                                  196  0.000982
     Child 18+ spouse of subfamily RP                   126  0.000632
     Other Rel 18+ never marr RP of subfamily            94  0.000471
     Child <18 never marr RP of subfamily                80  0.000401
     Spouse of RP of unrelated subfamily                 52  0.000261
     Child <18 ever marr not in subfamily                36  0.000180
     Grandchild 18+ ever marr not in subfamily           34  0.000170
     Grandchild 18+ spouse of subfamily RP               10  0.000050
     Grandchild 18+ ever marr RP of subfamily             9  0.000045
     Child <18 ever marr RP of subfamily                  9  0.000045
     Other Rel <18 ever marr RP of subfamily              6  0.000030
     Grandchild 18+ never marr RP of subfamily            6  0.000030
     Other Rel <18 never married RP of subfamily          4  0.000020
     Other Rel <18 spouse of subfamily RP                 3  0.000015
     Child <18 spouse of subfamily RP                     2  0.000010
     Grandchild <18 ever marr not in subfamily            2  0.000010
     Grandchild <18 never marr RP of subfamily            2  0.000010
     Other Rel <18 ever marr not in subfamily             1  0.000005
    
    
    --------------------Summary_Household-------------------------
                                           total   percent
     Householder                           75475  0.378277
     Child under 18 never married          50426  0.252733
     Spouse of householder                 41709  0.209044
     Child 18 or older                     14430  0.072322
     Other relative of householder          9703  0.048631
     Nonrelative of householder             7601  0.038096
     Group Quarters- Secondary individual    132  0.000662
     Child under 18 ever married              47  0.000236
    
    
    --------------------Migration_Code_Change_Reg -------------------------
                       total   percent
     ?                 99696  0.499672
     Nonmover          82538  0.413677
     MSA to MSA        10601  0.053132
     NonMSA to nonMSA   2811  0.014089
     Not in universe    1516  0.007598
     MSA to nonMSA       790  0.003959
     NonMSA to MSA       615  0.003082
     Abroad to MSA       453  0.002270
     Not identifiable    430  0.002155
     Abroad to nonMSA     73  0.000366
    
    
    --------------------Migration Code-Move Within Reg-------------------------
                                     total   percent
     ?                               99696  0.499672
     Nonmover                        82538  0.413677
     Same county                      9812  0.049177
     Different county same state      2797  0.014018
     Not in universe                  1516  0.007598
     Different region                 1178  0.005904
     Different state same division     991  0.004967
     Abroad                            530  0.002656
     Different division same region    465  0.002331
    
    
    --------------------Stay_Same_House_1 -------------------------
                                   total   percent
     ?                             99696  0.499672
     Nonmover                      82538  0.413677
     Same county                    9812  0.049177
     Different county same state    2797  0.014018
     Not in universe                1516  0.007598
     Different state in South        973  0.004877
     Different state in West         679  0.003403
     Different state in Midwest      551  0.002762
     Abroad                          530  0.002656
     Different state in Northeast    431  0.002160
    
    
    --------------------Migration_Prev_Res_Sunbelt-------------------------
                                        total   percent
     Not in universe under 1 year old  101212  0.507270
     Yes                                82538  0.413677
     No                                 15773  0.079054
    
    
    --------------------Num_Persons_Worked_Employer-------------------------
                      total   percent
     ?                99696  0.499672
     Not in universe  84054  0.421275
     No                9987  0.050054
     Yes               5786  0.028999
    
    
    --------------------Country_Birth_Father-------------------------
                              total   percent
     Not in universe         144232  0.722884
     Both parents present     38983  0.195381
     Mother only present      12772  0.064013
     Father only present       1883  0.009438
     Neither parent present    1653  0.008285
    
    
    --------------------Country_Birth_Mother-------------------------
                                    total   percent
     United-States                 159163  0.797718
     Mexico                         10008  0.050160
     ?                               6713  0.033645
     Puerto-Rico                     2680  0.013432
     Italy                           2212  0.011086
     Canada                          1380  0.006916
     Germany                         1356  0.006796
     Dominican-Republic              1290  0.006465
     Poland                          1212  0.006074
     Philippines                     1154  0.005784
     Cuba                            1125  0.005638
     El-Salvador                      982  0.004922
     China                            856  0.004290
     England                          793  0.003974
     Columbia                         614  0.003077
     India                            580  0.002907
     South Korea                      530  0.002656
     Ireland                          508  0.002546
     Jamaica                          463  0.002321
     Vietnam                          457  0.002290
     Guatemala                        445  0.002230
     Japan                            392  0.001965
     Portugal                         388  0.001945
     Ecuador                          379  0.001900
     Haiti                            351  0.001759
     Greece                           344  0.001724
     Peru                             335  0.001679
     Nicaragua                        315  0.001579
     Hungary                          306  0.001534
     Scotland                         247  0.001238
     Iran                             233  0.001168
     Yugoslavia                       217  0.001088
     Taiwan                           199  0.000997
     Cambodia                         196  0.000982
     Honduras                         194  0.000972
     France                           191  0.000957
     Outlying-U S (Guam USVI etc)     159  0.000797
     Laos                             154  0.000772
     Trinadad&Tobago                  113  0.000566
     Thailand                         107  0.000536
     Hong Kong                        106  0.000531
     Holand-Netherlands                51  0.000256
     Panama                            25  0.000125
    
    
    --------------------Country_Birth_Self-------------------------
                                    total   percent
     United-States                 160479  0.804313
     Mexico                          9781  0.049022
     ?                               6119  0.030668
     Puerto-Rico                     2473  0.012395
     Italy                           1844  0.009242
     Canada                          1451  0.007272
     Germany                         1382  0.006927
     Philippines                     1231  0.006170
     Poland                          1110  0.005563
     Cuba                            1108  0.005553
     El-Salvador                     1108  0.005553
     Dominican-Republic              1103  0.005528
     England                          903  0.004526
     China                            760  0.003809
     Columbia                         612  0.003067
     South Korea                      609  0.003052
     Ireland                          599  0.003002
     India                            581  0.002912
     Vietnam                          473  0.002371
     Japan                            469  0.002351
     Jamaica                          453  0.002270
     Guatemala                        444  0.002225
     Ecuador                          375  0.001879
     Peru                             355  0.001779
     Haiti                            353  0.001769
     Portugal                         342  0.001714
     Nicaragua                        301  0.001509
     Hungary                          297  0.001489
     Greece                           261  0.001308
     Scotland                         241  0.001208
     Taiwan                           222  0.001113
     Honduras                         218  0.001093
     France                           212  0.001063
     Iran                             198  0.000992
     Yugoslavia                       177  0.000887
     Outlying-U S (Guam USVI etc)     157  0.000787
     Cambodia                         157  0.000787
     Laos                             155  0.000777
     Thailand                         123  0.000616
     Hong Kong                        107  0.000536
     Trinadad&Tobago                   99  0.000496
     Holand-Netherlands                49  0.000246
     Panama                            32  0.000160
    
    
    --------------------Citizenship -------------------------
                                    total   percent
     United-States                 176989  0.887061
     Mexico                          5767  0.028904
     ?                               3393  0.017006
     Puerto-Rico                     1400  0.007017
     Germany                          851  0.004265
     Philippines                      845  0.004235
     Cuba                             837  0.004195
     Canada                           700  0.003508
     Dominican-Republic               690  0.003458
     El-Salvador                      689  0.003453
     China                            478  0.002396
     South Korea                      471  0.002361
     England                          457  0.002290
     Columbia                         434  0.002175
     Italy                            419  0.002100
     India                            408  0.002045
     Vietnam                          391  0.001960
     Poland                           381  0.001910
     Guatemala                        344  0.001724
     Japan                            339  0.001699
     Jamaica                          320  0.001604
     Peru                             268  0.001343
     Ecuador                          258  0.001293
     Haiti                            228  0.001143
     Nicaragua                        218  0.001093
     Taiwan                           201  0.001007
     Portugal                         174  0.000872
     Iran                             157  0.000787
     Greece                           147  0.000737
     Honduras                         144  0.000722
     Ireland                          135  0.000677
     France                           121  0.000606
     Outlying-U S (Guam USVI etc)     119  0.000596
     Thailand                         113  0.000566
     Laos                             105  0.000526
     Hong Kong                        100  0.000501
     Cambodia                          95  0.000476
     Hungary                           79  0.000396
     Scotland                          75  0.000376
     Trinadad&Tobago                   66  0.000331
     Yugoslavia                        66  0.000331
     Panama                            28  0.000140
     Holand-Netherlands                23  0.000115
    
    
    --------------------Business_Type-------------------------
                                                   total   percent
     Native- Born in the United States            176992  0.887076
     Foreign born- Not a citizen of U S            13401  0.067165
     Foreign born- U S citizen by naturalization    5855  0.029345
     Native- Born abroad of American Parent(s)      1756  0.008801
     Native- Born in Puerto Rico or U S Outlying    1519  0.007613
    
    
    --------------------Veterans_Questionnaire-------------------------
                       total   percent
     Not in universe  197539  0.990056
     No                 1593  0.007984
     Yes                 391  0.001960
    
    
    


```python
edit_columns = ['state_previous_residence','migration code-move within reg' , 
             'stay_same_house_1 ', 'num_persons_worked_employer', 'country_birth_mother', 
             'country_birth_self', 'citizenship ','migration_code_change_reg ' ]
# Replace ? with Unknown
for col in edit_columns:
    data.loc[data[col] == ' ?', col] = 'unknown'
```


```python
# Check if ? is present
for col in edit_columns:
    print(f"? in {col}: {data[(data[col] == '?')].any().sum()}")
```

    ? in state_previous_residence: 0
    ? in migration code-move within reg: 0
    ? in stay_same_house_1 : 0
    ? in num_persons_worked_employer: 0
    ? in country_birth_mother: 0
    ? in country_birth_self: 0
    ? in citizenship : 0
    ? in migration_code_change_reg : 0
    


```python
hs_grad = [' High school graduate',' 11th grade',' 10th grade',' 9th grade',' 12th grade no diploma']
elementary = [' 1st 2nd 3rd or 4th grade',' Less than 1st grade',' 7th and 8th grade',' 5th or 6th grade']

#replace elements in list.
data['education'].replace(hs_grad,' HS-grad',inplace = True)
data['education'].replace(to_replace = elementary,value = ' elementary_school',inplace = True)
data['education'].value_counts()
```




     HS-grad                                   71196
     Children                                  47422
     Some college but no degree                27820
     Bachelors degree(BA AB BS)                19865
     elementary_school                         13902
     Masters degree(MA MS MEng MEd MSW MBA)     6541
     Associates degree-occup /vocational        5358
     Associates degree-academic program         4363
     Prof school degree (MD DDS DVM LLB JD)     1793
     Doctorate degree(PhD EdD)                  1263
    Name: education, dtype: int64




```python
plt.style.use('seaborn-whitegrid')
fig = plt.figure(figsize=(20,4)) 
sns.countplot(y="education", data=data);
```


![png](output_14_0.png)



```python
married= [' Married-civilian spouse present',' Married-spouse absent',' Married-A F spouse present']
separated = [' Separated',' Divorced',' Widowed']

#replace elements in list.
data['marital status'].replace(to_replace = married ,value = 'Married',inplace = True)
data['marital status'].replace(to_replace = separated,value = 'Separated',inplace = True)
data['marital status'].value_counts()
```




     Never married    86485
    Married           86405
    Separated         26633
    Name: marital status, dtype: int64




```python
plt.figure(figsize=(20,3)) 
sns.countplot(y="marital status", data=data);
```


![png](output_16_0.png)



```python
plt.style.use('seaborn-whitegrid')
plt.figure(figsize=(20,3)) 
sns.countplot(y="class", data=data);
```


![png](output_17_0.png)



```python
self_employed = [' Self-employed-not incorporated',' Self-employed-incorporated']
govt_employees = [' State government',' Federal government', ' Local government']

#replace elements in list.
data['class'].replace(to_replace = self_employed ,value = 'Self_employed',inplace = True)
data['class'].replace(to_replace = govt_employees,value = 'Govt_employees',inplace = True)

data['class'].value_counts()
```




     Not in universe    100245
     Private             72028
    Govt_employees       14936
    Self_employed        11710
     Never worked          439
     Without pay           165
    Name: class, dtype: int64




```python
plt.style.use('seaborn-whitegrid')
plt.figure(figsize=(20,10)) 
sns.countplot(y="country_birth_self", data=data);
```


![png](output_19_0.png)



```python
US = [' United-States']
Outside_US = ['unknown', ' Cambodia',' Canada', ' China', ' Columbia', ' Cuba', ' Dominican-Republic', ' Ecuador', ' El-Salvador', ' England',
              ' France', ' Germany',' Greece',' Guatemala', ' Haiti', ' Holand-Netherlands', ' Honduras', ' Hong Kong', ' Hungary',
              ' India', ' Iran', ' Ireland', ' Italy', ' Jamaica', ' Japan', ' Laos', ' Mexico', ' Nicaragua', ' Outlying-U S (Guam USVI etc)', ' Panama',
              ' Peru', ' Philippines', ' Poland', ' Portugal', ' Puerto-Rico', ' Scotland', ' South Korea', ' Taiwan', ' Thailand',
              ' Trinadad&Tobago', ' Vietnam', ' Yugoslavia']

#replace elements in list.
data['country_birth_self'].replace(to_replace = US ,value = 'US',inplace = True)
data['country_birth_self'].replace(to_replace = Outside_US,value = 'Outside_US',inplace = True)

data['country_birth_self'].value_counts()
```




    US            160479
    Outside_US     39044
    Name: country_birth_self, dtype: int64




```python
plt.style.use('seaborn-colorblind')
plt.figure(figsize=(20,10)) 
sns.countplot(y="country_birth_self", data=data);
```


![png](output_21_0.png)



```python
plt.style.use('seaborn-bright')
plt.figure(figsize=(20,10)) 
sns.countplot(y="citizenship ", data=data);
```


![png](output_22_0.png)



```python
US = [' United-States']
Outside_US = ['unknown', ' Cambodia',' Canada', ' China', ' Columbia', ' Cuba', ' Dominican-Republic', ' Ecuador', ' El-Salvador', ' England',
              ' France', ' Germany',' Greece',' Guatemala', ' Haiti', ' Holand-Netherlands', ' Honduras', ' Hong Kong', ' Hungary',
              ' India', ' Iran', ' Ireland', ' Italy', ' Jamaica', ' Japan', ' Laos', ' Mexico', ' Nicaragua', ' Outlying-U S (Guam USVI etc)', ' Panama',
              ' Peru', ' Philippines', ' Poland', ' Portugal', ' Puerto-Rico', ' Scotland', ' South Korea', ' Taiwan', ' Thailand',
              ' Trinadad&Tobago', ' Vietnam', ' Yugoslavia']

#replace elements in list.
data['citizenship '].replace(to_replace = US ,value = 'US',inplace = True)
data['citizenship '].replace(to_replace = Outside_US,value = 'Outside_US',inplace = True)
data['citizenship '].value_counts() # Country_Birth_Mother
```




    US            176989
    Outside_US     22534
    Name: citizenship , dtype: int64




```python
plt.style.use('seaborn-bright')
plt.figure(figsize=(20,10)) 
sns.countplot(y="citizenship ", data=data);
```


![png](output_24_0.png)



```python
plt.style.use('seaborn-whitegrid')
plt.figure(figsize=(20,10)) 
sns.countplot(y="country_birth_mother", data=data);
```


![png](output_25_0.png)



```python
US = [' United-States']
Outside_US = ['unknown', ' Cambodia',' Canada', ' China', ' Columbia', ' Cuba', ' Dominican-Republic', ' Ecuador', ' El-Salvador', ' England',
              ' France', ' Germany',' Greece',' Guatemala', ' Haiti', ' Holand-Netherlands', ' Honduras', ' Hong Kong', ' Hungary',
              ' India', ' Iran', ' Ireland', ' Italy', ' Jamaica', ' Japan', ' Laos', ' Mexico', ' Nicaragua', ' Outlying-U S (Guam USVI etc)', ' Panama',
              ' Peru', ' Philippines', ' Poland', ' Portugal', ' Puerto-Rico', ' Scotland', ' South Korea', ' Taiwan', ' Thailand',
              ' Trinadad&Tobago', ' Vietnam', ' Yugoslavia']

#replace elements in list.
data['country_birth_mother'].replace(to_replace = US ,value = 'US',inplace = True)
data['country_birth_mother'].replace(to_replace = Outside_US,value = 'Outside_US',inplace = True)

data['country_birth_mother'].value_counts() # Country_Birth_Mother
```




    US            159163
    Outside_US     40360
    Name: country_birth_mother, dtype: int64




```python
plt.style.use('seaborn-whitegrid')
plt.figure(figsize=(20,10)) 
sns.countplot(y="country_birth_mother", data=data);
```


![png](output_27_0.png)



```python
plt.figure(figsize =(12,6));
sns.countplot(x = 'income', data = data);
plt.xlabel("Income",fontsize = 12);
plt.ylabel("Frequency",fontsize = 12);
#Our dataset has 187000 people earning <=50K i.e. 93% and remainng 7% earns more than 50K.
```


![png](output_28_0.png)



```python
data[list(num_column.index)].hist(figsize = (12,12));
```


![png](output_29_0.png)



```python
table_occ = pd.crosstab(data['major_occupation_code'], data['income'])
table_class = pd.crosstab(data['class'], data['income'])
table_edu = pd.crosstab(data['education'], data['income'])
table_marital = pd.crosstab(data['marital status'], data['income'])
table_race = pd.crosstab(data['mace'],data['income'])
table_sex = pd.crosstab(data['sex'], data['income'])

fig = plt.figure(figsize = (17,6))

ax = fig.add_subplot(1,2,1)
(table_occ.div(table_occ.sum(axis= 1),axis = 0)*100).sort_values(by= 0).plot(kind = 'bar',ax=ax);
plt.xlabel("Occupation",fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 15);


ax = fig.add_subplot(1,2,2)
plt.style.use('seaborn-whitegrid')
(table_class.div(table_class.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',ax=ax);
plt.xlabel("class",fontsize = 15);
```


![png](output_30_0.png)



```python
fig = plt.figure(figsize = (17,6))
ax = fig.add_subplot(1,2,1)
(table_edu.div(table_edu.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',ax =ax);
plt.xlabel('Education',fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 14);


ax = fig.add_subplot(1,2,2)
(table_marital.div(table_marital.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',ax = ax);
plt.xlabel('Marital Status',fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 14);
```


![png](output_31_0.png)



```python
fig = plt.figure(figsize = (17,6))
ax = fig.add_subplot(1,2,1)
(table_race.div(table_race.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',ax =ax);
plt.xlabel('Race',fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 14);

ax = fig.add_subplot(1,2,2)
(table_sex.div(table_sex.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',ax =ax);
plt.xlabel('Sex',fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 14);
```


![png](output_32_0.png)



```python
table_country = pd.crosstab(data['country_birth_self'], data['income'])
(table_country.div(table_country.sum(axis = 1),axis = 0)*100).sort_values(by = 0).plot(kind = 'bar',figsize = (17,6));
plt.xlabel('Native Country',fontsize = 14);
plt.ylabel('Proportion of People',fontsize = 14);
```


![png](output_33_0.png)



```python
#Sex:- Out of total male 10 -15% of them earn salary more than 50K while less than 10% female earn more than 50K. 
#      92 -96% female earn less than 50K
#Race:- White and asain-pac-Islander earn salary more than 50K
#marital_status :- 15% of married people seem to earn salary greater than 50K.
#People having degree doctorate,professional school degree ,masters are earning salary more than 50K.
#Out of all the workclass, self employed people and government employess are making salary more than 50K.

```


```python
fig = plt.figure(figsize = (12,10))

sns.heatmap(data[list(num_column.index)].corr(),annot = True,square = True);


#From the following heatma we can find few varialbe like weeks worked in year, family_below_18, 
#industry_code are highly correlated.

```


![png](output_35_0.png)



```python
fig = plt.figure(figsize = (17,10))
ax = fig.add_subplot(2,1,1)
sns.stripplot('age ', 'capital_gains', data = data,
         jitter = 0.2,ax = ax);
plt.xlabel('Age',fontsize = 12);
plt.ylabel('Capital Gain',fontsize = 12);

ax = fig.add_subplot(2,1,2)
sns.stripplot('age ', 'capital_gains', data = data,
         jitter = 0.2);
plt.xlabel('Age',fontsize = 12);
plt.ylabel('Capital Gain',fontsize = 12);
plt.ylim(0,40000);


#Between age 22 and 64 capital gain is upto 15000 and after that it increases and decreases at age 81.
#Age 89 doesn't follow the pattern.
```


![png](output_36_0.png)



```python
fig = plt.figure(figsize = (17,10))
ax = fig.add_subplot(2,1,1)
sns.stripplot('weeks_year', 'capital_gains', data = data,
         jitter = 0.2,ax = ax);
plt.xlabel('weeks worked in year',fontsize = 12);
plt.ylabel('Capital Gain',fontsize = 12);

ax = fig.add_subplot(2,1,2)
sns.stripplot('weeks_year', 'capital_gains', data = data,
         jitter = 0.2,ax = ax);
plt.xlabel('weeks worked in year',fontsize = 12);
plt.ylabel('Capital Gain',fontsize = 12);
plt.ylim(0,40000);


#Majority of people can be seen working for 40,48,50 and 52 weeks per year and their capital gain seems to be high.
#There are few people working for 0 weeks for year  but have good capital gains. 
#week 31 has very low captial gains when compared to week 30 and week 32
```


![png](output_37_0.png)



```python
fig = plt.figure(figsize = (17,6))

sns.stripplot('age ','weeks_year', data = data,
         jitter = 0.2);
plt.xlabel('Age',fontsize = 12);
plt.ylabel('weeks in year',fontsize = 12);
```


![png](output_38_0.png)



```python
num_col_update = ['age ','capital_gains', 'capital_losses','weeks_year' ,'instance_weight', 'family_below_18']
cat_col_update = ['class', 'education','enrolled edu inst last wk', 'marital status', 'major_industry_code', 'major_occupation_code', 
                'mace' ,'hispanic', 'sex' ,'member_labor_union', 'reason_unemployment' , 'employment_type',
               'tax_status' ,'region_previous_residence','state_previous_residence' ,
                'household_family_stat' ,'summary_household' ,'migration_code_change_msa', 'migration_code_change_reg ',
                'migration code-move within reg' , 'stay_same_house_1 ','migration_prev_res_sunbelt', 
                'num_persons_worked_employer','country_birth_father','country_birth_mother' ,
                'country_birth_self' ,'citizenship ', 'business_type','taxable_inc_amount', 'veterans_questionnaire' ,
                'veterans_benefits' , 'income']
```


```python
#using Minmax scaler because as we saw from the various trends that different features have different scale.
from sklearn.base import TransformerMixin
from sklearn.preprocessing import MinMaxScaler,StandardScaler, RobustScaler
scaler = RobustScaler()
pd.DataFrame(scaler.fit_transform(data[num_col_update]),columns = num_col_update).head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>capital_gains</th>
      <th>capital_losses</th>
      <th>weeks_year</th>
      <th>instance_weight</th>
      <th>family_below_18</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.142857</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-0.153846</td>
      <td>1.0</td>
      <td>-0.25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.714286</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.846154</td>
      <td>0.0</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.428571</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-0.153846</td>
      <td>1.0</td>
      <td>-0.25</td>
    </tr>
  </tbody>
</table>
</div>




```python
cat_df['id'] = pd.Series(range(cat_df.shape[0]))
num_df['id'] = pd.Series(range(num_df.shape[0]))
```


```python
finaldata = pd.merge(cat_df,num_df,how = 'inner', on = 'id')
print(f"Number of observations in final dataset: {finaldata.shape}")
```

    Number of observations in final dataset: (199523, 270)
    


```python
y = finaldata['income']
finaldata.drop(labels = ['id','income'],axis = 1,inplace = True)
X = finaldata
```


```python
from sklearn.model_selection import train_test_split,cross_val_score,GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,roc_curve, auc
from datetime import datetime
from sklearn.feature_selection import RFE
```


```python
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size =0.3,random_state = 42)
```

# Logistic Regression


```python
#Without Hyper Parameters Tuning
#Logistic Regression
from sklearn.linear_model import LogisticRegression
model= LogisticRegression(random_state=123)
model.fit(X_train,y_train)
prediction=model.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Accuracy: 0.9515177840519906
    Recall Score: 0.7101359703337453
    Precision Score: 0.32077051926298156
    ROC_AUC curve: 0.8341799204679596
    Confusion Matrix:
     [[55806  2433]
     [  469  1149]]
    


```python
#With Hyper Parameters Tuning
#Logistic Regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
model= LogisticRegression(random_state=123)
params = {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000],
          'penalty' : ['l1', 'l2'],
          'solver' : ['liblinear', 'saga'],
          'class_weight' : [{1:0.5, 0:0.5}, {1:0.4, 0:0.6}, {1:0.6, 0:0.4}]
         }
model1 = GridSearchCV(model, param_grid=params, n_jobs=8, verbose=2)
model1.fit(X_train,y_train)
print("Best Hyper Parameters:",model1.best_params_)
prediction=model1.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Fitting 3 folds for each of 84 candidates, totalling 252 fits
    

    [Parallel(n_jobs=8)]: Using backend LokyBackend with 8 concurrent workers.
    [Parallel(n_jobs=8)]: Done  25 tasks      | elapsed:  2.3min
    [Parallel(n_jobs=8)]: Done 146 tasks      | elapsed: 15.0min
    [Parallel(n_jobs=8)]: Done 252 out of 252 | elapsed: 25.9min finished
    

    Best Hyper Parameters: {'C': 1, 'class_weight': {1: 0.5, 0: 0.5}, 'penalty': 'l1', 'solver': 'liblinear'}
    Accuracy: 0.9520858045007268
    Recall Score: 0.692972972972973
    Precision Score: 0.35790061418202124
    ROC_AUC curve: 0.8266612929753585
    Confusion Matrix:
     [[55707  2300]
     [  568  1282]]
    

# Decision Tree


```python
#Without Hyper Parameters Tuning
#DesicionTree
from sklearn.tree import DecisionTreeClassifier
model= DecisionTreeClassifier(random_state=123)
model.fit(X_train,y_train)
prediction=model.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Accuracy: 0.9299998329351621
    Recall Score: 0.42213114754098363
    Precision Score: 0.4600781686208822
    ROC_AUC curve: 0.6937832117881136
    Confusion Matrix:
     [[54019  1934]
     [ 2256  1648]]
    


```python
#With Hyper Parameters Tuning
#DesicionTree
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
model= DecisionTreeClassifier(random_state=123)
params = {'max_features': ['auto', 'sqrt', 'log2'],
          'min_samples_split': [2,3,4,5,6,7,8,9,10], 
          'min_samples_leaf':[1,2,3,4,5,6,7,8,9],
          'class_weight' : [{1:0.5, 0:0.5}, {1:0.4, 0:0.6}, {1:0.6, 0:0.4}, 'balanced']
          }
model1 = GridSearchCV(model, param_grid=params, n_jobs=8, verbose=2)
model1.fit(X_train,y_train)
print("Best Hyper Parameters:",model1.best_params_)
prediction=model1.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Fitting 3 folds for each of 972 candidates, totalling 2916 fits
    

    [Parallel(n_jobs=8)]: Using backend LokyBackend with 8 concurrent workers.
    [Parallel(n_jobs=8)]: Done  25 tasks      | elapsed:   15.8s
    [Parallel(n_jobs=8)]: Done 146 tasks      | elapsed:   42.4s
    [Parallel(n_jobs=8)]: Done 349 tasks      | elapsed:  1.5min
    [Parallel(n_jobs=8)]: Done 632 tasks      | elapsed:  2.4min
    [Parallel(n_jobs=8)]: Done 997 tasks      | elapsed:  3.7min
    [Parallel(n_jobs=8)]: Done 1442 tasks      | elapsed:  5.3min
    [Parallel(n_jobs=8)]: Done 1969 tasks      | elapsed:  7.2min
    [Parallel(n_jobs=8)]: Done 2576 tasks      | elapsed:  9.3min
    [Parallel(n_jobs=8)]: Done 2916 out of 2916 | elapsed: 10.4min finished
    

    Best Hyper Parameters: {'class_weight': {1: 0.5, 0: 0.5}, 'max_features': 'auto', 'min_samples_leaf': 8, 'min_samples_split': 2}
    Accuracy: 0.9474079890405467
    Recall Score: 0.6220472440944882
    Precision Score: 0.30876605248464545
    ROC_AUC curve: 0.7897078280425264
    Confusion Matrix:
     [[55603  2476]
     [  672  1106]]
    

# KNN Neighbors


```python
#Without Hyper Parameters Tuning
#kNearestNeighbors
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train,y_train)
prediction=model.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Accuracy: 0.9439497468967707
    Recall Score: 0.5760214333556597
    Precision Score: 0.2400893355667225
    ROC_AUC curve: 0.7646915473268601
    Confusion Matrix:
     [[55642  2722]
     [  633   860]]
    


```python
#With Hyper Parameters Tuning and grid search
#kNearestNeighbors
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
params = {'n_neighbors':[3,5,7,8,9,10,12],
          'leaf_size':[10,12,30,50,100],
          'weights' : ['distance']}
model1 = GridSearchCV(model, param_grid=params,n_jobs=8, verbose=2)
model1.fit(X_train,y_train)
print("Best Hyper Parameters:\n",model1.best_params_)
prediction=model1.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
print("Recall Score:",metrics.recall_score(prediction,y_test))
print("Precision Score:",metrics.precision_score(prediction,y_test))
print("ROC_AUC curve:",metrics.roc_auc_score(prediction,y_test))
print("Confusion Matrix:\n",metrics.confusion_matrix(prediction,y_test))
```

    Fitting 3 folds for each of 35 candidates, totalling 105 fits
    

    [Parallel(n_jobs=8)]: Using backend LokyBackend with 8 concurrent workers.
    [Parallel(n_jobs=8)]: Done  25 tasks      | elapsed: 18.6min
    [Parallel(n_jobs=8)]: Done 105 out of 105 | elapsed: 59.5min finished
    

    Best Hyper Parameters:
     {'leaf_size': 10, 'n_neighbors': 12, 'weights': 'distance'}
    Accuracy: 0.9471740982675376
    Confusion Matrix:
     [[55940  2827]
     [  335   755]]
    Recall Score: 0.6926605504587156
    Precision Score: 0.21077610273590172
    ROC_AUC curve: 0.822277660666763
    Confusion Matrix:
     [[55940  2827]
     [  335   755]]
    
